# Source capability alignment — bounded graph closure

Execution mode: **implement and verify in the current authorized Source checkout through the existing `source-e2e` controller. No new controller, registry, graph abstraction, or receipt ledger.**

## Deliverable and first executable action

Deliver the existing internal Search path as a correctly described, resource-qualified, receipt-bound capability, consumed by a real downstream Source task. Keep all public exposure and existing protected-operation gates intact. This is the graph slice of the complete capability-alignment program, not a new graph implementation project.

First action: bind the active checkout and read its actual instructions, `source-e2e` definition/parser, manifest generator, `graph_query`, `adapter_graph_query`, `_run_graph`, `bounded_gds_path_projection`, `aura_gds_projection`, and `allow_search_waist_gds`. Resolve exact files/identities and callers rather than assuming paths. The operator supplied `scripts/aura_gds_offload.py` as a related implementation reference; inspect it only where it exists. Use the root already supplied by the execution environment; do not search the filesystem for a checkout or overlay. Do not restore an old commit or bootstrap an existing installation.

Record current branch/HEAD, affected-file preimages, unrelated dirty files, served identity, operation-contract identity, canonical owner, supported controller mode, release path and required tests. Historical served pins in this package are comparison evidence, not a checkout target. A changed generation requires revalidation of affected joins, not an unbounded restart of the audit.

## Correction precedence

This document and `GRAPH_ALIGNMENT_DELTA.json` supersede the earlier conversation's graph-specific instructions where inconsistent. The broader `IMPLEMENTATION_ONESHOT.md` remains applicable.

**Do not force `graph_gds` from `VOID` to `LIVE`.** The observed family ledger is scoped to a public/curated profile. A public availability status can correctly be `VOID` while internal Search has a working adapter. Establish the actual contract meaning, preserve backward-compatible `LIVE | PARTIAL | VOID` output, and add or use existing orthogonal implementation, exposure, authorization, effects, resource and verification fields. Do not introduce `INTERNAL_RESTRICTED` into an enum without a real compatibility requirement and migration decision.

**Do not claim a total-work bound from a returned-row limit.** Retain the database-side cap; inspect upstream operators, accepted query shapes, byte limits and timeout handling separately. The row cap is materially stronger than a post-fetch slice, but neither caps all upstream scans, aggregation, sort or procedure computation. A scalar result can still be large or expensive. `LIMIT` never substitutes for write denial. [N01–N02]

**Do not claim an active five-minute execution limit from `PT5M`.** Verify the helper's argument mapping. If it maps to provider `ttl`, that is inactive-session expiration. Bind an explicit active workload/deadline/cancellation policy using the existing owner; do not fabricate one from the TTL. Qualified billable-session admission must account for the documented ten-minute minimum; do not presume a free/trial exemption or invent a current tariff. [N03–N05]

**Do not upgrade operator reports or panel agreement into independently verified runtime facts.** The operator reports 29 tests passing and an implemented adapter. Reuse that evidence as a locator; inspect exact bytes, test scope and actual served execution before advancing acceptance. Q08's frozen `_missing` remains a synthetic negative fixture; Q17 refusal guards stay intact.

## Implementation scope

### A. Extend the existing manifest projection

Keep all seven semantic classes distinct. Resolve canonical capability IDs in the existing registry; the package's G01–G07 labels are document keys, not proposed public API names.

| Class | Existing reported owner | Required distinction |
|---|---|---|
| Ordinary bounded Cypher | `graph_query` | Internal Search retrieval, not a Neo4j MCP grant |
| Exact GDS metadata allowlist | `graph_query` | `gds.version`, `gds.list`, `gds.graph.list`, `gds.graph.exists`; preserve actual function/procedure forms |
| Bounded Skill-pair PageRank | `bounded_gds_path_projection` | Dedicated AGA compute, temporary resources and possible cost |
| Unbounded GDS streaming | `graph_query` | `REFUSED_BY_DESIGN` |
| GDS writes/mutations | `graph_query` | `REFUSED_BY_DESIGN` |
| Arbitrary projections | `graph_query` | `REFUSED_BY_DESIGN` |
| Neo4j MCP procedure catalog | Plugin reference interface | Discovery/reference, not authority for this Search path |

Generate projections from existing definitions. Add no public tool merely to equalize counts. A public profile need not reveal sensitive internal details; return only the intended capability summary. A missing item in a filtered public discovery result is not proof that its internal adapter is absent. A documented withheld surface counts toward inventory accounting, not available functionality.

### B. Preserve and qualify actual bounds

For ordinary Search Cypher, verify the emitted driver statement and parameters, not a debug string or post-fetch list. Maintain a maximum 50-row result, the reported 15-second query timeout, finite fetching and connection/result cleanup. Preserve smaller valid limits. Reject unsupported grammar rather than silently executing a weakened rewrite. Exercise literal and parameterized limits, comments, terminators, quoted/backticked identifiers, subqueries, UNION, metadata calls, dynamic procedure wrappers and invalid values. Use the existing reviewed parser/template policy; this package does not provide a substitute regex sanitizer.

For AGA, verify the Skill→Skill candidate restriction before projection, no more than 2,000 input pair rows, actual 2GB allocation and PT5M inactive TTL. A pair-row cap is not a 2,000-node cap; two endpoints per pair imply at most 4,000 distinct endpoints before additional documented restrictions. Verify actual projected node/edge membership and no later expansion beyond the admitted pairs. Specify directedness, relationship types, duplicates, sampling and selection digest. Do not add a full sort solely for determinism without assessing its plan cost; either use an efficient deterministic selection or disclose bounded sampling.

Keep PageRank output scoped to this projected subgraph. Record algorithm/configuration, stopping parameters and top-N. Validate finite scores and original IDs. Centrality is a prioritization signal, not factual authority, causal importance or global ranking over all Source skills.

Read `allow_search_waist_gds()` and all callers. Verify default deny, exact owner-scoped grant, restoration on success/exception, nesting and actual thread/task semantics. A thread-local variable alone is not evidence of safe asynchronous task isolation. The global `THESRC_AURA_GDS_SESSIONS_ENABLED` flag, MCP write-Cypher, and plugin discovery must not authorize this internal Search path.

Separate durable graph mutation, ephemeral projection/session allocation, reads and incurred cost. Reconcile global budget/concurrency/reservation controls through the existing owner. Fail closed on unqualified paid allocation, without expanding this task into a new billing subsystem.

### C. Close the actual consumer chain

Demonstrate one scoped user task:

`task/request → policy and budget admission → selected query/inputs → owned AGA session/projection → PageRank → complete result → resource cleanup → downstream consumption → assessed outcome`

Use existing receipt identities at every link. Carry canonical capability/version, actual implementation and served generation, request/tenant/input digest, emitted query/parameters, input selection/projection digest, session/projection IDs, actual execution plane, algorithm/config, result reference/hash/count/range, cleanup disposition and the downstream consumer's exact result binding.

Reconstruct retained bytes; compare hashes locally and through the real readback contract. An envelope marked clean, a displayed hash or a conferred PASS is insufficient. Do not claim actor-distinct verification unless identity binding establishes it. Receipt creation itself does not mean outcome acceptance or learning promotion.

Observe both graph cleanup and the session's resource lifecycle. Depending on the existing helper/provider, one action may close both; do not invent duplicate delete calls. Verify the actual consequence. Do not delete another request's shared session. If a deliberately reused session is supported, retain explicit owned reuse/budget/expiry evidence and adapt the proposed evidence mapping; never assert that a running reused session is deleted. The supplied verifier targets the operator-described temporary per-run session path and intentionally requires terminal deletion/expiry for that path.

On failure after allocation, preserve uncertain effects and the exact owned cleanup handle. Reconcile before retrying. A request timeout is not proof that paid computation stopped. Fault-inject failures in an isolated environment at allocation, extraction, projection, algorithm, serialization, consumer disconnect and cleanup. Do not exercise unsafe negative payloads against production.

### D. Implement the minimum verified delta, then test

Do not redesign already-correct adapters. Patch the actual generator/consumer mismatch or missing bound only where bytes/tests substantiate it. For each actual changed responsibility, produce the narrow diff, regression and consumer evidence. Existing availability semantics can be preserved; the task is not complete merely by adding explanatory prose.

Run actual Source suites discovered from the checkout, including `test_search_read_adapter`, `test_aura_gds_cost_gate`, Q17 guards and Q08 fixture/runtime separation where their names resolve. Run the applicable G01–G26 obligations in `ACCEPTANCE_MATRIX.json`, plus the affected original A01–A20 obligations. Report exact test IDs and collected/executed/passed/failed/skipped/uncollected counts. A skip or synthetic fixture cannot satisfy required integration evidence.

Use `verify_graph_evidence.py` only to check the exported record's internal consistency. It is not an execution route, Cypher authorization layer, Source test suite or independent acceptance authority. Map current native receipt fields into its logical fields without building another ledger. The empty template must remain failing until real evidence is available.

### E. Integrate, release and read back through the existing path

Finish reversible local implementation/tests under current authority. Preserve unrelated dirty work and concurrent edits. Deployment, migration, push/merge, credentials, production graph writes and other protected operations require their existing exact-target gates; repeated `go/fullsend` does not remove them.

When the actual release is authorized, deploy the narrow change through its current owner and rollback path. Re-read serving identities and affected manifest projections. Compare public tool identity/schema and authorization semantics before/after; equal tool counts do not prove unchanged grants. Run permitted internal Search journeys and isolated refusal tests through intended surfaces. Where public MCP deliberately does not expose the adapter, record that disposition—do not use a proxy/federation workaround.

The earlier diagnostic timeout and fleet `COMPOSITION_FAILURE` remain parallel residuals unless they block this specific acceptance. Do not repeat broad diagnostics or add conferral rounds instead of delivering the bounded patch.

## Current connector boundary to preserve

A direct read-only `source-e2e` status probe on September 17, 2026 returned:

```text
PROFILE_ROUTE_DENIED
profile: claude_user_read
operation_attempted: false
operation_executed: false
operation_receipt_id: null
outer_invocation_id: 03da0024-382a-5627-aac9-ea295bf6ee1b
```

Do not retry that generic route, substitute another proxy or write a context-field note and call it implementation. The prior asynchronous run is terminal `degraded` with `ReadTimeout` and `NOT_OBSERVED` acceptance; no asynchronous job needs to be left pending or reissued for this package.

## Exit criteria

Return the actual owner map, changed files/diff, generated projection delta, required test results, complete input/result/cleanup/consumer evidence, release status and remaining exact predicate. Keep these levels separate:

`PACKAGE_UPDATED → REPOSITORY_IMPLEMENTED → REPOSITORY_TESTED → AUTHORIZED_RELEASE → SERVED_CONTRACT_MATCH → CONSUMER_ACCEPTED`

The package already reaches the first level only. Repository implementation requires the real execution environment. A blocked release does not erase completed local work, and local work does not prove a release. Do not claim full CLI/API/MCP parity unless the complete native CLI census and required cross-surface journeys actually satisfy their separate predicates.
