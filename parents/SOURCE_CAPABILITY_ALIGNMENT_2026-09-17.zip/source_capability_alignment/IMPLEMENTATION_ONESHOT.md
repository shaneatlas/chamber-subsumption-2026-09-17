# Source CLI/API/MCP capability-manifest alignment — implementation directive

Execution mode: **repository-local implementation, verification and authorized release through the existing Source controller.** Complete reachable work in this run. Preserve target-specific gates; do not substitute a design report for implementation where the checkout and authority are available.

## September 17 graph correction — controlling addendum

Read `GRAPH_CLOSURE_ONESHOT.md` and `GRAPH_ALIGNMENT_DELTA.json` before selecting the graph work. They preserve the internal Search-waist boundary, distinguish public VOID from internal implementation, and correct LIMIT/TTL/cleanup claims. Original inventory and runtime flags in the manifest are historical snapshot evidence, not a September 17 recensus. The actual current controller probe was denied; no repository integration is claimed.

## Objective and boundary

Make Source’s declared capabilities correspond to its actual CLI functionality and expose equivalent semantics through the intended API/MCP profiles, **in descending use-case leverage**. Optimize completed useful workflows, not tool count. Alignment does not mean every CLI function becomes a public remote tool.

Use the existing `source-e2e` controller where its current definition and actual parser establish the appropriate internal mode. Discover its syntax; this directive intentionally does not invent a shell command or flags. Do not replace the controller, capability registry, gateway, routing system, receipt ledger, task system, graph abstraction or learning fabric.

The supplied package is non-authoritative integration input. Its offline checks do not prove Source tests, production deployment or functional parity. The observed served SHA `d5bf2e38ae5f1f7764a906d3b0cf6619d4590af7` and generation `39817908e6a87fc0` are historical pins to compare against, not deployment targets to restore.

In scope: capability identity and manifest generation; CLI parser/handler/skill/command bindings; API/MCP exposure; per-leaf effect and access contracts; owned state and continuity; general retrieval and reranking; bounded execution and closure; reasoning; ingestion; diagnostics; graph discovery; learning; target-scoped operator operations; preservation of domain functionality.

Out of scope: Casa, unrelated websites, storefront redesign, outreach, account provisioning, blanket public access, broad dependency upgrades or a new provider stack. Protect unrelated dirty work and other sessions.

## 1. Establish one deployable checkpoint and the current owner

Start with the smallest usable checkpoint, not another review of the whole plan:

**First checkpoint:** an authorized client can read an owned Source task/checkpoint, obtain relevant non-biomedical Source evidence through the existing retrieval owner, and reconstruct its retained result with honest identity, completeness and access semantics.

**First execution checkpoint:** one already-working, explicitly authorized reversible operation travels through the existing controller with joined plan, invocation, actual effect, complete readback and acceptance. No task claim, description of a tool call or conferred prose counts as an executed effect.

Read the current controller and owner definitions before selecting the actual first action. State the first unmet predicate and next concrete action against current evidence. Find the existing delivery owner, release path, required checks and independent readback. Do not invent names or a deployment window. Where a real window is recorded, protect capacity for implementation, required checks, integration, release, consumer acceptance and recovery.

Use one bounded review of load-bearing changes and act on actionable findings. Reopen a passed review only for changed evidence or scope. Do not expand an alignment repair into unbounded governance reconstruction.

## 2. Read visible inputs and capture exact state

Use the active checkout or an explicitly supplied repository root. Do not search the filesystem for a checkout or `MU5KOSX_ACTIVE.md`; apply an overlay only if visible and applicable. Enumerate the exact input files used. Respect the checkout’s actual instructions and ownership.

Read `CAPABILITY_ALIGNMENT.md`, `ALIGNMENT_MANIFEST.json`, `EVIDENCE_REGISTER.json` and `ACCEPTANCE_MATRIX.json`. Verify `SHA256SUMS.txt` before relying on package bytes. The following project artifacts are useful only where present and applicable: `SOURCE_GUARD_FIRST_ONESHOT.md`, `SOURCE_IMPLEMENTATION_SPEC.md`, `source-e2e-actualize.md` and `Pasted markdown(90).md`. Their older runtime claims are revalidation targets, not present truth.

Capture repository root, branch, HEAD, dirty paths, affected-file preimages, actual running/served build, catalog hash, schema fingerprint, declared operation-contract identity and current profile. Do not equate local HEAD with served identity. Never initialize, bootstrap or migrate an existing instance as part of discovery. Do not read or echo credential values.

If served generation changes during enumeration, preserve the old observations and obtain a coherent new snapshot for the affected joins. A stable catalog hash is insufficient: this conversation observed changing schema/generation with an unchanged catalog hash.

## 3. Reuse and reconcile the real canonical owners

Read definitions, constraints, policies, writers, readers and tests for the existing `public.capability_registry`. A bounded metadata read found it and reported 22 columns, but the connector response was truncated; the full schema and row semantics are still unverified.

Observed fields already cover capability identity/class, risk, public/authenticated/operator/admin flags, plan/human-approval/receipt/substrate-write/shell requirements, allowed/denied surfaces, verifier, closure gate and version. Reuse them rather than creating competing flags. Verify deprecation semantics and the remaining column. Classify each needed responsibility as EXISTS, PARTIAL, ANALOGOUS, ABSENT, CONFLICTING or DEPRECATED with its actual owner and evidence.

Candidate owners from the project record—**resolve actual definitions rather than assuming paths or present semantics**—include `v_cadt_candidate_capability_current`, `compile_cadt_admission`, `v_capability_denial`, `cadt_runtime_contract.py`, `v_provider_call_cost_v2`, the provider-call writers, `surface_ontology.py`, `v_divergent_model_leverage`, and `rerank_wire.py`.

Build a finite revision-bound inventory of actual CLI parser commands/subcommands, aliases, native skills/commands, entry points and callable leaf handlers; API routes; native MCP schemas; registered substrate operations; composites; generated help/manifests; and intended profiles. Keep distinct count domains. The supplied 225 declarations and 42 native bindings are starting sets, not the CLI denominator.

Resolve underscore/dotted identities by explicit authoritative joins. Similar spelling is not proof of equivalence. Distinguish reference-only vendor skills from native Source definitions and executable implementations. Do not activate every PG-only or disk-only skill solely to improve a parity percentage.

## 4. Fix the load-bearing manifest defects before widening exposure

**Effect/access honesty.** Trace `source_task_batch_claim`, `source_evidence_attach_batch`, `promotion-worker`, `source-sync` and comparable declarations to actual leaf behavior. Their discovery labels overlap mutation-described semantics; this is a verification target, not a demonstrated bypass. Split preview/status from persistent updates and privileged actions as needed. Composite authorization must follow the exact selected leaves and target, not a blanket READ label or HTTP method.

**Contract breadth.** Keep `source_search` and `source_ask` explicitly biomedical unless the real implementation is deliberately extended and tested. Do not use them as evidence that arbitrary repository/API knowledge retrieval is served. Join `repo_search`, `corpus_knowledge`, `helpdoc_manifest` and comparable listed capabilities to real supported handlers or return an exact unavailable/withheld disposition. In this session, `repo_search` appeared in a profile list but not the queried operation/command projection; that is not proof its implementation is absent everywhere.

**Unsupported actions.** `source_ask` declares `authority`, `variants` and `substrates` not implemented in contract v1. Return machine-distinguishable NOT_IMPLEMENTED rather than a misleading no-data result, preserving supported-client compatibility through versioning or a typed additive discriminator.

**Controller binding.** `source-e2e` was discovered as DISK_ONLY with no PG binding. Read its native body and bind existing modes through the real owner. A vendor-only `source.skills.read` contract does not establish native definition access, much less native execution.

**Complete output/readback.** Repair the actual serialization/transport/presentation boundary that truncated the capability-registry query and readback mid-JSON despite a clean envelope. Return structured results or a supported content-addressed, paginated retrieval path. State total bytes/items, returned range, continuation, completeness, canonical serialization and hash scope. Do not merely increase a prose cutoff or truncate silently. Reconstruct and hash-check a result across each intended client.

**Output contracts.** Add or reconcile output/error schemas for the ten native mirrors lacking declared output schemas where appropriate. Preserve precise no-match, unsupported, unavailable, denied, failed, partial, cancellation and unknown-effect states. Schema declaration alone does not prove conformance.

**Per-query admission.** Exact system-task/context-by-task reads currently declare shared-operator-key admission and reject OAuth/scoped credentials. Do not bypass that boundary. An owned-task OAuth read requires an intentional authorized implementation with tenant/ownership checks and negative tests; otherwise retain the explicit supported operator path.

The current `source.substrate.change.plan/apply` operations only manage operator-owned context fields. They are not capability-registry or source-code editing endpoints. Do not store a note there and declare this manifest aligned.

## 5. Implement in leverage order, with dependencies attached

| Order | Stable use-case ID | Concrete work and exit predicate |
|---|---|---|
| 0 | P0 | Canonical identity, effect classification and honest discovery. Every in-scope command/handler has one canonical operation or an explicit typed disposition. |
| 1 | UC01 | Continue an owned project, task or session across clients. A task opened by the CLI is read by the connector with the same stable identity and checkpoint. |
| 2 | UC02 | Retrieve and rerank actual Source evidence across domains. The same scoped code/corpus query returns semantically equivalent evidence IDs on CLI/API/MCP. |
| 3 | UC07 | Use bounded internal graph intelligence with complete consumer provenance. A real traversal returns a reproducible path with serving-plane provenance. |
| 4 | UC04 | Use Source reasoning, routing and conferral as real capabilities. Equivalent requests use the same governed semantics across surfaces. |
| 5 | UC03 | Execute and close bounded work through the existing Source controller. The same authorized operation has joined plan, invocation, effect and readback across CLI/API/MCP. |
| 6 | UC05 | Admit documents, artifacts and corrections into reusable knowledge. An authorized artifact is admitted once and retrieved by stable ID through another client. |
| 7 | UC06 | Diagnose a failure and inspect its proof. The retained result is reconstructable and hash-verifiable end to end. |
| 8 | UC08 | Assess outcomes, improve routing and promote accepted learning. A result is assessed against an exact task, policy and checkpoint. |
| 9 | UC09 | Operate, update and repair the Source fleet. Each selected update has an owner, target, version, approval, rollback and result. |
| 10 | UC10 | Preserve and expand specialized product packs. Implemented actions return substantive typed results or real no-match, while unimplemented actions report NOT_IMPLEMENTED. |

Ranks are default decision guidance, not measured ROI or permission to ignore prerequisites. Receipt integrity and security ship with every slice, not after rank 6. A lower-ranked primitive may move earlier only when it directly unblocks the chosen higher-leverage acceptance. Record the reason rather than expanding scope silently.

## 6. Generate, do not manually fork, surface manifests

Extend the strongest existing canonical generator. Separate stable capability definitions from the immutable manifest of one accepted execution. Generate CLI help, API/OpenAPI and MCP discovery projections from the same owned contract where their syntax permits; preserve profile-specific exposure.

Join canonical identity/version/owner, explicit aliases, input/output/errors, supported actions, composite defaults and leaf selection, semantic effects, principal/tenant/target admission, required plan/approval, intended surface, dependencies, implementation revision, freshness/provenance, retained result and verification requirements. Use existing columns and normalized relations; create the minimum compatible extension only for an evidenced missing responsibility.

Keep transport differences at the adapter boundary. Tool count, response prose, optional UI, local paths and host-selected conversation models need not be identical. Capability semantics, effects, permissions, evidence identity and closure criteria must align. Do not give the connector authority over its host’s outer model loop.

No generic raw shell/SQL or unbounded federation endpoint should appear as a shortcut to parity. Represent full operator utility through typed, target-specific operations and the actual approval path. Undiscoverable, host-local and withheld capabilities remain accounted for without leaking sensitive detail.

## 7. Run actual tests and the first consumer journey

Use the existing repository test commands and relevant suites discovered from the checkout. The package’s `python3 -m unittest` is only an offline audit check. Implement and execute the applicable obligations in `ACCEPTANCE_MATRIX.json` using the actual handlers.

Test exact-set accounting and generator determinism; alias collisions; per-leaf effects; schema/error compatibility; principal/tenant isolation; unsupported actions; native versus vendor reads; same evidence IDs across clients; stable candidate-set reranking; partial conferrals; large complete results; stale generations; unknown-effect reconciliation; payload-bound idempotency; cancellation custody; and no silent promotion.

Use isolated fixtures for mutations and fault injection. Running a test that alters production is still a mutation requiring the target’s existing approval. Read-only product tests may proceed where authorized. Missing credentials or unsupported authentication terminate that branch without unchanged retries or privilege substitution; they do not excuse skipping unrelated offline implementation.

Report collected, executed, passed, failed, skipped and uncollected tests with exact commands, revision, environment and reasons. A missing integration dependency must not turn the release green through skip or import fallback.

Finish each slice by running the actual user journey through CLI and the intended API/MCP consumer, with equivalent authorized principals and pinned data/release. Evaluate semantic output and evidence rather than demanding byte-identical stochastic prose. Preserve the original receipts and link the actual consumer readback; self-attestation is not an actor-distinct independent witness.

## 8. Integrate and release only through the current path

Preserve unrelated dirty files and concurrent edits. Apply narrowly scoped patches; avoid blanket staging, resets, cleanup or branch changes. Use the actual required independent reviewer and act on concrete findings; do not repeat an unchanged review merely to accumulate approval prose.

Production deploy/restart, schema migration apply, secrets/config changes, graph writes, pushes, merges and destructive operations retain their existing target-specific authority. This directive is not blanket approval for them. Prepare the exact release/rollback/check package even when live authority is absent, and finish every independently authorized implementation/test branch.

When release is authorized, rediscover the served contract and rerun the changed consumer journeys. Confirm identities and complete result readback from the served deployment, not local HEAD or a passing build. Retain the previous accepted release for the established rollback path; do not modify a previously accepted execution manifest in place.

## 9. Close with concrete evidence and no inflated denominator

Return the actual changed files/diffs, canonical owner map, exact CLI/capability crosswalk, generated manifest diff, test commands/results/skips, operation and acceptance receipts, served identity where released, and the next unmet predicate for every residual.

Account for every in-scope CLI operation as EQUIVALENT_VERIFIED, PARTIAL, INTENTIONALLY_WITHHELD, HOST_LOCAL_ONLY, NOT_IMPLEMENTED, DEPRECATED or UNKNOWN. A justified withheld exposure can close inventory accounting but is not available functionality. Do not count UNKNOWN as complete or remove it from a parity denominator. Report raw declarations and distinct canonical operations separately.

Distinguish PACKAGE_VALIDATED, REPOSITORY_IMPLEMENTED, REPOSITORY_TESTED, LIVE_CHECK_PASSED, SERVED_CONSUMER_ACCEPTED and PRODUCTION_PROMOTED. Advance each state only on its own evidence. If blocked, provide the exact missing environment, operation, target approval or evidence and completed work—not a generic request to “enable writes.”

**Termination:** deliver the highest-leverage usable checkpoint supported by current authority, with demonstrated behavior and exact residuals. Do not claim complete CLI parity from 42/42 native identity bindings, 225 catalog entries, skill counts, advisory conferral or this package’s passing tests.
