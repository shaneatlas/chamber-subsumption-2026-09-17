"""Offline graph-delta and exported-evidence checks; no Source or Neo4j calls."""
import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from validate_graph_alignment import check_graph_alignment
from verify_graph_evidence import verify, strict_json

ROOT=Path(__file__).resolve().parent

def manifest():return json.loads((ROOT/'ALIGNMENT_MANIFEST.json').read_text())

def setpath(obj,path,value):
    for k in path[:-1]:obj=obj[k]
    obj[path[-1]]=value

def fixture(root):
    """All bytes and event claims here are intentionally SYNTHETIC."""
    def ref(name,obj):
        data=json.dumps(obj,sort_keys=True).encode()
        (root/name).write_bytes(data)
        return {'path':name,'sha256':hashlib.sha256(data).hexdigest()}
    log=ref('synthetic-log.json',{'fixture':True,'notice':'Not a real Source run'})
    stmt=ref('synthetic-statement.json',{'fixture':True,'statement':'MATCH (s:Skill) RETURN s LIMIT 50'})
    params=ref('synthetic-params.json',{})
    pairs=[{'source':'skill:A','target':'skill:B','relationship_id':'r:1'}]
    pairref=ref('synthetic-pairs.json',pairs)
    resultref=ref('synthetic-result.json',[{'skill_id':'skill:A','score':1.0}])
    return {
     'schema':'source-graph-consumer-evidence/1.0','evidence_class':'SYNTHETIC_FIXTURE','claim_ceiling':'OFFLINE_CONSISTENCY_REQUIRES_SOURCE_ADJUDICATION',
     'generation':{'repository_sha':'a'*40,'served_sha':'a'*40,'catalog_sha16':'b'*16,'schema_fingerprint':'c'*16,'generation_id':'d'*16,'operation_contract_sha256':'e'*64},
     'request':{'request_id':'synthetic:request1','task_id':'synthetic:task1','principal_ref':'synthetic:principal','workspace_ref':'synthetic:workspace','input_sha256':'f'*64},
     'authorization':{'decision':'ALLOW','gate':'allow_search_waist_gds()','mcp_grant_used':False,'global_toggle_used':False,'request_id':'synthetic:request1','input_sha256':'f'*64,'evidence':log},
     'bounds':{'result_row_cap':50,'query_timeout_seconds':15,'projection_pair_cap':2000,'aga_memory':'2GB','aga_ttl':'PT5M','ttl_semantics':'INACTIVE_SESSION_EXPIRATION','active_deadline_seconds':240,'row_cap_is_total_work_cap':False,'active_deadline_policy_evidence':log},
     'query':{'emitted_statement':stmt,'parameters':params,'admission_and_bound_evidence':log,'bounds_verified_at_driver_boundary':True,'policy_validation_not_just_regex':True},
     'projection':{'projection_id':'synthetic:graph1','session_id':'synthetic:session1','owner_request_id':'synthetic:request1','execution_plane':'aura_graph_analytics','scope':'BOUNDED_SKILL_PAIR_SUBGRAPH','input_pairs':pairref,'reported_pair_count':1,'reported_node_count':2,'input_reexpanded':False,'creation_evidence':log},
     'result':{'artifact':resultref,'top_n':1,'row_count':1,'algorithm':'pageRank.stream','ranking_scope':'PROJECTED_SUBGRAPH_ONLY','complete':True,'byte_count':(root/resultref['path']).stat().st_size,'byte_cap':262144},
     'consumer':{'request_id':'synthetic:request1','result_sha256':resultref['sha256'],'consumed_skill_ids':['skill:A'],'acceptance':'OBSERVED','receipt_id':'synthetic:consumer','evidence':log},
     'cleanup':{'projection_id':'synthetic:graph1','session_id':'synthetic:session1','graph_drop_observed':True,'session_terminal_state':'DELETED','no_ongoing_compute_observed':True,'graph_evidence':log,'session_evidence':log},
     'budget':{'admission':'APPROVED','request_id':'synthetic:request1','tier_class':'BILLABLE','minimum_billed_minutes':10,'evidence':log},
     'public_exposure':{'native_names_before':['synthetic-native-tool'],'native_names_after':['synthetic-native-tool'],'authorization_digest_before':'1'*64,'authorization_digest_after':'1'*64,'profile_status':'VOID','profile_status_scope':'PUBLIC_CURATED_PROFILE','evidence':log},
     'source_checks':[{'id':f'G{i:02d}','status':'PASSED','execution_scope':'SOURCE_REPOSITORY_OR_SERVED_INTEGRATION','evidence':log} for i in range(1,27)],
     'source_suite':{'collected':29,'executed':29,'passed':29,'failed':0,'skipped':0,'uncollected':0,'evidence':log}}

class GraphAlignmentTests(unittest.TestCase):
    def test_graph_delta_consistent(self):self.assertEqual(check_graph_alignment(manifest()),[])
    def test_malformed_delta_refused(self):self.assertTrue(check_graph_alignment({}))
    def test_missing_capability_refused(self):
        m=manifest();m['graph_alignment']['capabilities'].pop();self.assertTrue(check_graph_alignment(m))
    def test_side_effect_free_checker(self):
        m=manifest();before=copy.deepcopy(m);check_graph_alignment(m);self.assertEqual(m,before)

GRAPH_MUTATIONS={
 'force_public_live':(['public_projection_policy','force_live'],True),
 'widen_mcp':(['public_projection_policy','expand_mcp_grants'],True),
 'erase_public_scope':(['public_projection_policy','scope'],'GLOBAL'),
 'claim_unverified_runtime':(['capabilities',2,'runtime_verified_here'],True),
 'wrong_aga_owner':(['capabilities',2,'reported_owner'],'neo4j_mcp'),
 'hide_cost':(['capabilities',2,'effect_class'],'PURE_READ_NO_COST'),
 'global_gate':(['capabilities',2,'reported_cost_gate'],'THESRC_AURA_GDS_SESSIONS_ENABLED'),
 'unbounded_allowed':(['capabilities',3,'policy'],'ALLOW'),
 'write_allowed':(['capabilities',4,'policy'],'ALLOW'),
 'project_allowed':(['capabilities',5,'policy'],'ALLOW'),
 'catalog_grants':(['capabilities',6,'policy'],'EXECUTION_AUTHORITY'),
 'row_cap_is_work_cap':(['bounds','max_compute_claim_from_limit'],True),
 'pairs_are_nodes':(['bounds','endpoint_node_upper_bound_derived'],2000),
 'ttl_is_deadline':(['bounds','aga_ttl_semantics'],'ACTIVE_MAX_RUNTIME'),
 'fabricated_deadline':(['bounds','active_job_deadline_seconds_verified'],300),
 'drop_is_termination':(['bounds','drop_graph_equals_delete_session'],True),
 'five_minute_billing':(['bounds','billable_minimum_minutes_documented'],5),
 'test_count_laundering':(['reported_tests','independently_rerun_here'],True),
 'fixture_is_runtime':(['fixture_policy','Q08_missing'],'RUNTIME_OWNER_ABSENT')}
for name,(path,value) in GRAPH_MUTATIONS.items():
    def test(self,path=path,value=value):
        m=manifest();setpath(m['graph_alignment'],path,value);self.assertTrue(check_graph_alignment(m))
    setattr(GraphAlignmentTests,'test_reject_'+name,test)

class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.p=fixture(self.root)
    def tearDown(self):self.tmp.cleanup()
    def test_synthetic_consistency_only(self):self.assertEqual(verify(self.p,self.root),[])
    def test_public_void_can_be_consistent(self):
        self.assertEqual(self.p['public_exposure']['profile_status'],'VOID');self.assertEqual(verify(self.p,self.root),[])
    def test_missing_artifact(self):
        (self.root/self.p['result']['artifact']['path']).unlink();self.assertTrue(verify(self.p,self.root))
    def test_changed_bytes(self):
        (self.root/self.p['result']['artifact']['path']).write_text('[]');self.assertTrue(verify(self.p,self.root))
    def test_outside_path(self):
        self.p['result']['artifact']['path']='../escape.json';self.assertTrue(verify(self.p,self.root))
    def test_duplicate_json_keys(self):
        with self.assertRaises(ValueError):strict_json(b'{"x":1,"x":2}')
    def test_nonfinite_json(self):
        with self.assertRaises(ValueError):strict_json(b'{"x":NaN}')
    def test_missing_checks(self):
        self.p['source_checks'].pop();self.assertTrue(verify(self.p,self.root))
    def test_malformed_packet(self):self.assertTrue(verify({},self.root))
    def test_checker_preserves_input(self):
        orig=copy.deepcopy(self.p);verify(self.p,self.root);self.assertEqual(orig,self.p)

EVIDENCE_MUTATIONS={
 'template_as_evidence':(['evidence_class'],'TEMPLATE_NOT_EXECUTED'),
 'live_claim':(['claim_ceiling'],'CLOSED'),
 'generation_skew':(['generation','served_sha'],'b'*40),
 'metadata_grant':(['authorization','mcp_grant_used'],True),
 'global_toggle':(['authorization','global_toggle_used'],True),
 'authorization_cross_request':(['authorization','request_id'],'foreign'),
 'row_cap':(['bounds','result_row_cap'],51),
 'bool_row_cap':(['bounds','result_row_cap'],True),
 'pair_cap':(['bounds','projection_pair_cap'],2001),
 'timeout':(['bounds','query_timeout_seconds'],16),
 'missing_active_deadline':(['bounds','active_deadline_seconds'],None),
 'ttl_deadline':(['bounds','ttl_semantics'],'ACTIVE_DEADLINE'),
 'work_limit_claim':(['bounds','row_cap_is_total_work_cap'],True),
 'not_driver_bound':(['query','bounds_verified_at_driver_boundary'],False),
 'regex_proof':(['query','policy_validation_not_just_regex'],False),
 'projection_reexpansion':(['projection','input_reexpanded'],True),
 'wrong_plane':(['projection','execution_plane'],'unknown'),
 'projection_cross_request':(['projection','owner_request_id'],'foreign'),
 'global_rank':(['result','ranking_scope'],'GLOBAL_SKILL_AUTHORITY'),
 'unlimited_top_n':(['result','top_n'],100),
 'truncated':(['result','complete'],False),
 'byte_count':(['result','byte_count'],999),
 'consumer_hash':(['consumer','result_sha256'],'0'*64),
 'consumer_orphan':(['consumer','consumed_skill_ids'],['skill:INVENTED']),
 'no_acceptance':(['consumer','acceptance'],'NOT_OBSERVED'),
 'cleanup_session':(['cleanup','session_terminal_state'],'RUNNING'),
 'graph_drop_only':(['cleanup','graph_drop_observed'],False),
 'unknown_resource':(['cleanup','no_ongoing_compute_observed'],False),
 'wrong_cleanup_identity':(['cleanup','session_id'],'foreign-session'),
 'five_minute_bill':(['budget','minimum_billed_minutes'],5),
 'unknown_budget':(['budget','admission'],'UNKNOWN'),
 'public_policy_change':(['public_exposure','authorization_digest_after'],'2'*64),
 'exposure_added':(['public_exposure','native_names_after'],['synthetic-native-tool','new-grant']),
 'skipped_suite':(['source_suite','skipped'],1),
 'uncollected_suite':(['source_suite','uncollected'],1),
 'fabricated_suite':(['source_suite','executed'],0),
 'not_run_check':(['source_checks',0,'status'],'NOT_RUN')}
for name,(path,value) in EVIDENCE_MUTATIONS.items():
    def test(self,path=path,value=value):
        setpath(self.p,path,value);self.assertTrue(verify(self.p,self.root))
    setattr(EvidenceTests,'test_reject_'+name,test)

if __name__=='__main__':unittest.main()
