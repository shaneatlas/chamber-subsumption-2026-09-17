"""Offline invariants for the graph delta. No Source execution or policy enforcement."""
from __future__ import annotations
from typing import Any


def check_graph_alignment(manifest: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    def require(ok: bool, message: str) -> None:
        if not ok: errors.append(message)
    try:
        g = manifest['graph_alignment']
        require(g['status'] == 'PROPOSED_ADDITIVE_CONTRACT_NOT_RUNTIME_REGISTRY', 'graph delta is not a runtime registry')
        p = g['public_projection_policy']
        require(p['scope'] == 'PUBLIC_CURATED_PROFILE', 'public projection scope erased')
        require(p['legacy_status_retained'] == 'VOID', 'observed public status must not be rewritten')
        require(p['force_live'] is False and p['expand_mcp_grants'] is False, 'public authority must not expand')
        require(set(p['required_dimension_separation']) == {'implementation','exposure','authorization','runtime_evidence','effect','resource_bounds'}, 'independent capability dimensions missing')
        caps = g['capabilities']
        by_id = {c['alignment_key']: c for c in caps}
        require(len(caps) == 7 and set(by_id) == {f'G{i:02d}' for i in range(1,8)}, 'graph capability exact set mismatch')
        for c in caps:
            require(c['runtime_verified_here'] is False, 'operator report cannot become runtime verification')
            require(c['public_mcp_grant_added'] is False, 'graph definition cannot add MCP authority')
            require(c['implementation_evidence'] == 'OPERATOR_REPORTED', 'implementation evidence class inflated')
        for key in ['G04','G05','G06']:
            require(by_id[key]['policy'] == 'REFUSED_BY_DESIGN', 'intentional refusal was removed')
        require(by_id['G01']['reported_owner'] == by_id['G02']['reported_owner'] == 'graph_query', 'Search owner identity changed')
        require(by_id['G03']['reported_owner'] == 'bounded_gds_path_projection', 'AGA owner identity changed')
        require(by_id['G03']['effect_class'] == 'EPHEMERAL_COMPUTE_WITH_POSSIBLE_COST', 'AGA compute/cost effect hidden')
        require(by_id['G03']['reported_cost_gate'] == 'allow_search_waist_gds()', 'Search cost gate replaced')
        require(set(by_id['G03']['forbidden_authority_sources']) == {'THESRC_AURA_GDS_SESSIONS_ENABLED','MCP write-Cypher','plugin procedure catalog'}, 'forbidden authorization shortcuts changed')
        require(by_id['G07']['policy'] == 'REFERENCE_ONLY_NOT_SOURCE_EXECUTION_AUTHORITY', 'plugin catalog misrepresented as authority')
        b=g['bounds']
        require(b['result_row_cap']==50 and b['query_timeout_seconds_reported']==15, 'reported Search bounds changed')
        require(b['projection_pair_cap']==2000 and b['endpoint_node_upper_bound_derived']==4000, 'pair/node bound conflated')
        require(b['aga_memory_requested']=='2GB' and b['aga_ttl_requested']=='PT5M', 'reported AGA settings changed')
        require(b['aga_ttl_semantics']=='INACTIVE_SESSION_EXPIRATION_IF_MAPPED_TO_PROVIDER_TTL', 'inactive TTL mistaken for active deadline')
        require(b['active_job_deadline_seconds_verified'] is None, 'unverified active deadline fabricated')
        require(b['max_compute_claim_from_limit'] is False, 'LIMIT promoted to universal compute bound')
        require(b['drop_graph_equals_delete_session'] is False, 'graph drop promoted to session termination')
        require(b['billing_tier_verified'] is False and b['billable_minimum_minutes_documented']==10, 'billing qualification fabricated')
        require(b['max_result_bytes_verified'] is None, 'row bound promoted to verified byte bound')
        require(set(g['required_gds_metadata'])=={'gds.version','gds.list','gds.graph.list','gds.graph.exists'}, 'metadata allowlist changed')
        require(g['reported_tests']=={'count':29,'scope':'OPERATOR_REPORTED_SOURCE_TESTS','independently_rerun_here':False}, 'reported29 tests relabeled as local Source execution')
        require(g['fixture_policy']['Q08_missing']=='SYNTHETIC_NEGATIVE_OWNER_ABSENT', 'Q08 fixture confused with runtime')
        require(g['fixture_policy']['runtime_owner_check']=='SEPARATE_REQUIRED', 'runtime owner test omitted')
        fam=next(f for f in manifest['product_families'] if f['family_id']=='graph_gds')
        require(fam['reported_catalog_status']=='VOID', 'historical family observation overwritten')
        require(fam['scope_correction']['is_global_implementation_verdict'] is False, 'public VOID treated as global absence')
        ranks={u['id']:u['rank'] for u in manifest['prioritized_use_cases']}
        require(ranks['UC07']==3 and ranks['UC03']==5, 'revised graph/execution leverage order missing')
        current=manifest['current_turn_observations']
        require(current['source_e2e_status_probe']['error']=='PROFILE_ROUTE_DENIED', 'actual refusal removed')
        require(current['source_e2e_status_probe']['operation_executed'] is False, 'refusal promoted to controller execution')
        require(current['previous_async_turn_readback']['consumer_acceptance']=='NOT_OBSERVED', 'degraded conferral promoted to accepted outcome')
        require(current['remote_calls_stopped_after_refusal'] is True, 'refused route was retried')
    except (KeyError, TypeError, ValueError, StopIteration, AttributeError) as exc:
        errors.append(f'malformed graph alignment: {exc}')
    return errors
