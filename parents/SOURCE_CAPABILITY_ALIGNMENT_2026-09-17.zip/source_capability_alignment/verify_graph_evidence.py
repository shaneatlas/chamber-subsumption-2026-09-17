#!/usr/bin/env python3
"""Check an exported graph-consumer evidence packet, never execute Source.

This is an OFFLINE consistency checker, not an authorization mechanism or a
live acceptance oracle. A valid packet still requires Source's existing
independent receipt/authenticity adjudication. Synthetic fixtures are labeled
and can never produce a live/closed verdict. File hashes prove byte identity,
not that reported events occurred. No network, shell, database or writes.

Usage: python3 verify_graph_evidence.py --packet CONSUMER_EVIDENCE.template.json
Exit 0: structurally consistent export/fixture, not live acceptance.
Exit 1: evidence incomplete/inconsistent. Exit 2: unreadable input.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any

MAX_FILE_BYTES=2*1024*1024
REQUIRED_CHECKS={f'G{i:02d}' for i in range(1,27)}
IDENTITY_FIELDS={'repository_sha':40,'served_sha':40,'catalog_sha16':16,'schema_fingerprint':16,'generation_id':16,'operation_contract_sha256':64}

def strict_json(data: bytes) -> Any:
    def pairs(items):
        result={}
        for key,value in items:
            if key in result: raise ValueError(f'duplicate JSON key: {key}')
            result[key]=value
        return result
    def constant(value): raise ValueError(f'non-finite JSON constant: {value}')
    return json.loads(data.decode('utf-8'),object_pairs_hook=pairs,parse_constant=constant)

def verify(packet: dict[str, Any], root: Path) -> list[str]:
    errors: list[str]=[]
    def need(ok: bool,message: str) -> None:
        if not ok: errors.append(message)
    def finite_positive(value: Any) -> bool:
        return type(value) in (float,int) and math.isfinite(value) and value>0
    def is_hash(value: Any,size: int=64) -> bool:
        return isinstance(value,str) and re.fullmatch('[0-9a-f]{'+str(size)+'}',value) is not None
    def text(value: Any) -> bool: return isinstance(value,str) and bool(value.strip())
    def artifact(ref: dict[str, Any],label: str) -> bytes | None:
        try:
            rel=Path(ref['path'])
            if rel.is_absolute() or '..' in rel.parts: raise ValueError('unsafe relative path')
            resolved=(root/rel).resolve()
            if not resolved.is_relative_to(root.resolve()): raise ValueError('file escapes packet root')
            if not resolved.is_file(): raise ValueError('file unavailable')
            if resolved.stat().st_size>MAX_FILE_BYTES: raise ValueError('file exceeds audit cap')
            data=resolved.read_bytes()
            need(is_hash(ref.get('sha256')),label+': valid SHA-256 required')
            need(hashlib.sha256(data).hexdigest()==ref.get('sha256'),label+': byte hash mismatch')
            return data
        except (KeyError,TypeError,OSError,ValueError) as exc:
            errors.append(label+': '+str(exc));return None
    try:
        need(packet['schema']=='source-graph-consumer-evidence/1.0','unknown packet schema')
        need(packet['evidence_class'] in {'SYNTHETIC_FIXTURE','EXTERNAL_RUN_EXPORT'},'template or unknown evidence class cannot pass')
        need(packet['claim_ceiling']=='OFFLINE_CONSISTENCY_REQUIRES_SOURCE_ADJUDICATION','no automatic live closure from this checker')
        gen=packet['generation']
        for key,n in IDENTITY_FIELDS.items(): need(is_hash(gen.get(key),n),'invalid generation.'+key)
        need(gen['repository_sha']==gen['served_sha'],'repository/served identity differs')
        request=packet['request']
        for key in ['request_id','task_id','principal_ref','workspace_ref']: need(text(request.get(key)),'request.'+key+' missing')
        need(is_hash(request.get('input_sha256')),'request digest missing')
        auth=packet['authorization']
        need(auth['decision']=='ALLOW' and auth['gate']=='allow_search_waist_gds()','owner-scoped authority missing')
        need(auth['mcp_grant_used'] is False and auth['global_toggle_used'] is False,'MCP/global flag cannot grant Search authority')
        need(auth['request_id']==request['request_id'] and auth['input_sha256']==request['input_sha256'],'authorization request binding mismatch')
        artifact(auth['evidence'],'authorization')
        limits=packet['bounds']
        need(type(limits['result_row_cap']) is int and 0<=limits['result_row_cap']<=50,'invalid result row cap')
        need(finite_positive(limits['query_timeout_seconds']) and limits['query_timeout_seconds']<=15,'invalid query timeout')
        need(type(limits['projection_pair_cap']) is int and 1<=limits['projection_pair_cap']<=2000,'invalid pair cap')
        need(limits['aga_memory']=='2GB' and limits['aga_ttl']=='PT5M','AGA reported allocation contract mismatch')
        need(limits['ttl_semantics']=='INACTIVE_SESSION_EXPIRATION','TTL must mean inactive-session expiration')
        need(finite_positive(limits['active_deadline_seconds']),'explicit policy-approved active deadline missing')
        need(limits['row_cap_is_total_work_cap'] is False,'row count is not total compute')
        artifact(limits['active_deadline_policy_evidence'],'active deadline policy')
        query=packet['query']
        artifact(query['emitted_statement'],'driver statement')
        artifact(query['parameters'],'driver parameters')
        artifact(query['admission_and_bound_evidence'],'actual handler admission/bound evidence')
        need(query['bounds_verified_at_driver_boundary'] is True,'driver-boundary bound evidence required')
        need(query['policy_validation_not_just_regex'] is True,'unsupported regex-only guard claim')
        projection=packet['projection']
        for key in ['projection_id','session_id','owner_request_id']: need(text(projection.get(key)),'projection.'+key+' missing')
        need(projection['owner_request_id']==request['request_id'],'projection owner mismatch')
        need(projection['execution_plane']=='aura_graph_analytics','actual execution plane must be explicit')
        need(projection['scope']=='BOUNDED_SKILL_PAIR_SUBGRAPH','projection scope is not bounded Skill-pair subgraph')
        inputs=artifact(projection['input_pairs'],'projection inputs')
        pairs=strict_json(inputs) if inputs is not None else []
        need(isinstance(pairs,list),'input pairs must be an array')
        node_ids=set()
        if isinstance(pairs,list):
            need(len(pairs)<=limits['projection_pair_cap'],'projection input exceeds pair cap')
            for pair in pairs:
                if not isinstance(pair,dict) or not all(text(pair.get(k)) for k in ['source','target','relationship_id']):
                    errors.append('invalid projection pair');continue
                node_ids.update([pair['source'],pair['target']])
        need(type(projection['reported_pair_count']) is int and projection['reported_pair_count']==len(pairs),'pair count mismatch')
        need(type(projection['reported_node_count']) is int and projection['reported_node_count']==len(node_ids),'node count mismatch')
        need(projection['input_reexpanded'] is False,'projected input cannot be silently expanded')
        artifact(projection['creation_evidence'],'projection creation')
        result=packet['result']
        result_bytes=artifact(result['artifact'],'result')
        rows=strict_json(result_bytes) if result_bytes is not None else []
        need(isinstance(rows,list),'result must be row array')
        need(type(result['top_n']) is int and 1<=result['top_n']<=limits['result_row_cap'],'invalid top-N')
        need(type(result['row_count']) is int and result['row_count']==len(rows) and len(rows)<=result['top_n'],'result row count exceeds bound or disagrees')
        seen=set()
        if isinstance(rows,list):
            for row in rows:
                if not isinstance(row,dict):errors.append('malformed result row');continue
                sid=row.get('skill_id');score=row.get('score')
                need(sid in node_ids,'output node outside projection')
                need(sid not in seen,'duplicate output identity');seen.add(sid)
                need(type(score) in (float,int) and math.isfinite(score),'score must be finite numeric')
        need(result['algorithm']=='pageRank.stream','unexpected algorithm')
        need(result['ranking_scope']=='PROJECTED_SUBGRAPH_ONLY','subgraph rank cannot become global authority')
        need(result['complete'] is True,'incomplete result')
        need(result_bytes is not None and result['byte_count']==len(result_bytes),'result byte count mismatch')
        need(type(result['byte_cap']) is int and 0<result['byte_cap']<=262144 and result['byte_count']<=result['byte_cap'],'missing/broken retained-byte bound')
        consumer=packet['consumer']
        need(consumer['request_id']==request['request_id'],'consumer request mismatch')
        need(consumer['result_sha256']==result['artifact']['sha256'],'consumer result hash mismatch')
        need(set(consumer['consumed_skill_ids'])<=seen and bool(consumer['consumed_skill_ids']),'consumer must use only actual result IDs')
        need(consumer['acceptance']=='OBSERVED' and text(consumer.get('receipt_id')),'consumer acceptance receipt missing')
        artifact(consumer['evidence'],'consumer readback')
        cleanup=packet['cleanup']
        need(cleanup['projection_id']==projection['projection_id'] and cleanup['session_id']==projection['session_id'],'cleanup identity mismatch')
        need(cleanup['graph_drop_observed'] is True,'graph cleanup not observed')
        need(cleanup['session_terminal_state'] in {'DELETED','EXPIRED'},'session termination not observed')
        need(cleanup['no_ongoing_compute_observed'] is True,'ongoing resource use uncertain')
        artifact(cleanup['graph_evidence'],'graph-drop evidence');artifact(cleanup['session_evidence'],'session termination evidence')
        budget=packet['budget']
        need(budget['admission']=='APPROVED' and budget['request_id']==request['request_id'],'bound budget admission missing')
        need(budget['tier_class'] in {'BILLABLE','VERIFIED_EXEMPT'},'billing tier not qualified')
        if budget['tier_class']=='BILLABLE':need(type(budget['minimum_billed_minutes']) is int and budget['minimum_billed_minutes']>=10,'billable minimum incorrectly treats TTL as cost')
        artifact(budget['evidence'],'budget qualification')
        exp=packet['public_exposure']
        before=exp['native_names_before'];after=exp['native_names_after']
        need(isinstance(before,list) and bool(before) and len(before)==len(set(before)),'invalid baseline native identity set')
        need(isinstance(after,list) and len(after)==len(set(after)) and set(before)==set(after),'public names changed without scope')
        need(is_hash(exp['authorization_digest_before']) and exp['authorization_digest_before']==exp['authorization_digest_after'],'public policy widened/changed')
        need(exp['profile_status'] in {'LIVE','PARTIAL','VOID'},'legacy profile enum invalid')
        need(exp['profile_status_scope']=='PUBLIC_CURATED_PROFILE','public profile scope lost')
        artifact(exp['evidence'],'public exposure diff')
        tests=packet['source_checks'];ids=[t['id'] for t in tests]
        need(len(ids)==len(set(ids)) and set(ids)==REQUIRED_CHECKS,'graph acceptance checks missing/duplicate')
        for test in tests:
            need(test['status']=='PASSED' and test['execution_scope']=='SOURCE_REPOSITORY_OR_SERVED_INTEGRATION','required Source check not executed/passed')
            artifact(test['evidence'],'check '+test['id'])
        suite=packet['source_suite']
        need(type(suite['executed']) is int and suite['executed']>0 and suite['collected']==suite['executed']==suite['passed'],'suite execution accounting mismatch')
        need(all(type(suite[k]) is int for k in ['collected','executed','passed','failed','skipped','uncollected']) and suite['failed']==suite['skipped']==suite['uncollected']==0,'required suite failure/skip/uncollected')
        artifact(suite['evidence'],'Source suite')
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError) as exc:
        errors.append('malformed/incomplete packet: '+str(exc))
    return errors

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet',type=Path,required=True)
    args=parser.parse_args()
    try:
        if args.packet.stat().st_size>MAX_FILE_BYTES:raise ValueError('packet exceeds audit cap')
        packet=strict_json(args.packet.read_bytes())
        if not isinstance(packet,dict):raise ValueError('packet root must be a JSON object')
        errors=verify(packet,args.packet.parent)
    except (OSError,UnicodeError,ValueError) as exc:
        print(json.dumps({'status':'INPUT_ERROR','error':str(exc)}));return 2
    cls=packet.get('evidence_class')
    result={'status':'EVIDENCE_INCOMPLETE_OR_INCONSISTENT' if errors else 'SYNTHETIC_FIXTURE_CONSISTENT' if cls=='SYNTHETIC_FIXTURE' else 'EXPORTED_EVIDENCE_CONSISTENT_REQUIRES_SOURCE_ADJUDICATION',
            'errors':errors,'source_execution_performed':False,'authenticity_independently_verified':False,'live_acceptance_granted':False}
    print(json.dumps(result,indent=2));return 1 if errors else 0
if __name__=='__main__':raise SystemExit(main())
