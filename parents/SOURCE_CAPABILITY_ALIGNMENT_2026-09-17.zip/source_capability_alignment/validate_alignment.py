#!/usr/bin/env python3
"""Validate this offline alignment package. This does not test or change Source.

Usage:
  python3 validate_alignment.py --package . --json
  python3 validate_alignment.py --package . --require-live --json

Exit codes: 0 = package valid; 1 = package invalid; 2 = input error;
3 = package valid but requested live-parity acceptance remains unproved.
No network calls, credentials, subprocesses, or Source writes are used.
"""
from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any

CATEGORIES = {
    'commands': 'command_ids', 'routes': 'route_ids',
    'composites': 'composite_ids', 'operations': 'operation_ids',
}
FAMILIES = {
    'bio_kg', 'legal', 'api_knowledge', 'commerce', 'identity_health',
    'governance_read', 'search_ask', 'session_lifecycle', 'object_resolve',
    'fleet_ops', 'perception_confer', 'patent_ip', 'financial',
    'ingest_corpus', 'graph_gds',
}


def check_package(manifest: dict[str, Any], evidence: dict[str, Any]) -> list[str]:
    """Return all detected inconsistencies; never infer runtime success."""
    errors: list[str] = []

    def require(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    def unique(values: list[Any], label: str) -> None:
        require(len(values) == len(set(values)), f'{label}: duplicate identity')

    try:
        require(manifest['package_schema'] in {'source-capability-alignment-audit/1.0', 'source-capability-alignment-audit/1.1'},
                'unsupported package schema')
        observation = manifest['observation']
        for key, size in [('served_sha', 40), ('catalog_sha16', 16),
                          ('schema_fingerprint', 16), ('generation_id', 16),
                          ('native_binding_manifest_sha256', 64), ('manifest_revision', 64)]:
            require(bool(re.fullmatch(r'[0-9a-f]{' + str(size) + '}', observation[key])),
                    f'observation.{key}: invalid hash/identity format')
        require('NOT_CLI_PARITY' in observation['claim_ceiling'],
                'identity observation must not claim CLI parity')

        entries = evidence['entries']
        evidence_ids = [item['id'] for item in entries]
        unique(evidence_ids, 'evidence')
        evidence_set = set(evidence_ids)
        require(bool(entries), 'evidence register is empty')
        for item in entries:
            require(bool(item.get('source')) and bool(item.get('limits')),
                    f'evidence {item.get("id")}: source/limitations required')

        def walk(node: Any) -> None:
            if isinstance(node, dict):
                for key, value in node.items():
                    if key == 'evidence_ids':
                        require(isinstance(value, list) and bool(value),
                                'evidence_ids must be a nonempty list')
                        if isinstance(value, list):
                            require(set(value) <= evidence_set, f'unresolved evidence reference: {value}')
                    walk(value)
            elif isinstance(node, list):
                for value in node:
                    walk(value)
        walk(manifest)

        census = manifest['capability_projection_census']
        require(census['final_next_cursor'] is None, 'projection pagination is incomplete')
        size = 0
        for category, key in CATEGORIES.items():
            ids = census[key]
            unique(ids, category)
            require(len(ids) == census['counts'][category], f'{category}: count mismatch')
            require(all(isinstance(i, str) and i.strip() for i in ids),
                    f'{category}: blank/non-string identity')
            size += len(ids)
        require(size == census['total_estimate_reported'], 'projection total mismatch')
        require(sum(census['page_sizes']) == size, 'page-size total mismatch')
        require('Not an exhaustive native CLI' in census['scope_note'],
                'projection scope must retain the CLI-census limitation')

        use_cases = manifest['prioritized_use_cases']
        use_ids = [item['id'] for item in use_cases]
        unique(use_ids, 'use cases')
        ranks = [item['rank'] for item in use_cases]
        unique(ranks, 'ranks')
        require(sorted(ranks) == list(range(len(use_cases))), 'ranks must be contiguous from zero')
        require(any(u['id'] == 'P0' and u['rank'] == 0 for u in use_cases), 'P0 must precede expansion')
        for use in use_cases:
            require(use['rank_basis'] == 'RECOMMENDATION_NOT_MEASURED_ROI',
                    f'{use["id"]}: do not report estimated priority as measured ROI')
            require(bool(use['acceptance']) and bool(use['required_alignment']),
                    f'{use["id"]}: acceptance and work definition required')
            require(use['status'] == 'DESIGN_READY_NOT_INTEGRATED',
                    f'{use["id"]}: this snapshot contains no integration evidence')
        use_set = set(use_ids)

        tools = manifest['native_tool_crosswalk']
        names = [item['tool_name'] for item in tools]
        unique(names, 'native tools')
        unique([item['capability_id'] for item in tools], 'native capability bindings')
        require(len(tools) == observation['tool_count_reported'], 'native tool count mismatch')
        require(observation['registered_tool_count_reported'] != observation['tool_count_reported'],
                'registered and exposed count domains were conflated')
        for item in tools:
            require(item['primary_use_case'] in use_set, 'native tool has unknown use case')
            require(item['binding_status'] == 'IDENTITY_SCHEMA_BOUND', 'binding status changed without evidence')
            require(item['functional_parity'] == 'NOT_ESTABLISHED', 'identity binding is not functional parity')
            require(type(item['output_schema_declared']) is bool, 'output schema declaration must be boolean')

        ops = manifest['operation_crosswalk']
        op_ids = [item['operation_id'] for item in ops]
        unique(op_ids, 'operation crosswalk')
        require(set(op_ids) == set(census['operation_ids']), 'operation crosswalk is not an exact set')
        for op in ops:
            require(op['primary_use_case'] in use_set, 'operation has unknown use case')
            require(op['gate'] in {'READ', 'WRITE', 'HARD_GATE'}, 'invalid operation gate')
            if op['operation_id'].startswith('source.substrate.change.'):
                require(op['implementation_scope'] == 'OPERATOR_OWNED_CONTEXT_FIELD_ONLY',
                        'context-field changes must not be repurposed as manifest edits')
                expected = 'WRITE' if op['operation_id'].endswith('.plan') else 'HARD_GATE'
                require(op['gate'] == expected, 'context-field change gate mismatch')
        require({o['operation_id'] for o in ops if o['runtime_test_in_this_turn']} ==
                {'source.substrate.query', 'source.operation.readback'},
                'runtime test claims exceed observed operations')

        families = manifest['product_families']
        family_ids = [item['family_id'] for item in families]
        unique(family_ids, 'product families')
        require(set(family_ids) == FAMILIES, 'product family accounting incomplete')
        require(Counter(f['reported_catalog_status'] for f in families) ==
                Counter({'LIVE': 10, 'PARTIAL': 1, 'VOID': 4}), 'reported family status counts changed')
        for family in families:
            require(family['primary_use_case'] in use_set, 'family has unknown use case')
            require(family['functional_parity'] == 'NOT_ESTABLISHED',
                    'family declaration is not functional acceptance')

        rows = manifest['declaration_crosswalk']
        row_keys = [(r['declaration_kind'], r['declaration_id']) for r in rows]
        unique(row_keys, 'declaration crosswalk')
        expected_keys = {(kind, i) for kind, field in [('command','command_ids'), ('route','route_ids'),
                         ('composite','composite_ids'), ('operation','operation_ids')] for i in census[field]}
        require(set(row_keys) == expected_keys, 'declaration crosswalk is not an exact set')
        by_use = {u['id']: u['rank'] for u in use_cases}
        for row in rows:
            require(row['proposed_primary_use_case'] in use_set, 'declaration has unknown use case')
            require(row['delivery_rank'] == by_use.get(row['proposed_primary_use_case']),
                    'declaration priority mismatch')
            require(row['cli_semantic_parity'] == 'NOT_VERIFIED', 'declaration has unproved CLI parity')
            require(row['priority_mapping_basis'] == 'AUTHORED_USE_CASE_TRIAGE_NOT_HANDLER_VERIFICATION',
                    'declaration triage is not handler verification')

        web = manifest['web_read_projection']
        unique(web['tool_ids'], 'web-read projection')
        require(len(web['tool_ids']) == web['declared_count_derived'], 'web-read count mismatch')
        require(set(web['not_native_in_curated']) == set(web['tool_ids']) - set(names),
                'profile set difference is incorrect')
        require('not automatically a defect' in web['caveat'], 'profile difference caveat missing')

        inventory = manifest['skill_inventory_reported']
        # Counts are returned inventory statistics, not a per-skill audit.
        require(inventory['bound_disk_and_pg'] + inventory['disk_only'] == inventory['disk_count'],
                'disk inventory arithmetic mismatch')
        require(inventory['bound_disk_and_pg'] + inventory['pg_only'] == inventory['postgres_active_count'],
                'Postgres inventory arithmetic mismatch')

        registry = manifest['canonical_registry']
        require(registry['relation'] == 'public.capability_registry', 'existing registry owner changed')
        require(registry['full_schema_verified'] is False, 'truncated schema cannot be marked fully verified')
        require(registry['row_values_policies_constraints_and_consumers_read'] is False,
                'metadata-only read cannot prove rows/policies/consumers')
        require(len(registry['observed_columns']) + registry['unread_column_names'] ==
                registry['column_count_reported'], 'registry column accounting mismatch')
        require(any(c['metadata_status'] == 'NAME_VISIBLE_METADATA_TRUNCATED'
                    for c in registry['observed_columns']), 'truncation was erased')

        unique([f['id'] for f in manifest['findings']], 'findings')
        unique([r['id'] for r in manifest['residuals']], 'residuals')
        require(bool(manifest['residuals']), 'this observation has unresolved integration residuals')
        for finding in manifest['findings']:
            require(finding['primary_use_case'] in use_set, 'finding has unknown use case')

        state = manifest['delivery_state']
        require(state['package_validation'] in {'PENDING', 'PASS'}, 'invalid package validation state')
        for field in ['repository_integrated', 'live_manifest_changed', 'production_promoted']:
            require(state[field] is False, f'{field}: no supporting delivery evidence in this package')
        require(state['source_cli_semantic_parity'] == 'NOT_VERIFIED', 'unproved CLI parity claim')
        require(manifest['visibility']['source_checkout_mounted'] is False,
                'this snapshot did not inspect a Source checkout')
    except (KeyError, TypeError, ValueError, AttributeError) as exc:
        errors.append(f'malformed package: {exc}')
    if manifest.get('package_schema') == 'source-capability-alignment-audit/1.1':
        from validate_graph_alignment import check_graph_alignment
        errors.extend(check_graph_alignment(manifest))
    return errors


def live_blockers(manifest: dict[str, Any]) -> list[str]:
    """Do not convert a passing offline check into a live release verdict."""
    reasons = [f'{r["id"]}: {r["detail"]}' for r in manifest.get('residuals', [])]
    state = manifest.get('delivery_state', {})
    if not state.get('repository_integrated'):
        reasons.append('No repository integration evidence.')
    if state.get('source_cli_semantic_parity') != 'VERIFIED':
        reasons.append('No exact native CLI census plus CLI/API/MCP semantic acceptance evidence.')
    if not state.get('live_manifest_changed'):
        reasons.append('No manifest change or independent served-consumer readback was performed.')
    return reasons


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--require-live', action='store_true')
    parser.add_argument('--json', action='store_true', help='Print machine-readable result')
    args = parser.parse_args()
    try:
        manifest = json.loads((args.package / 'ALIGNMENT_MANIFEST.json').read_text(encoding='utf-8'))
        evidence = json.loads((args.package / 'EVIDENCE_REGISTER.json').read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        print(json.dumps({'status': 'INPUT_ERROR', 'error': str(exc)}, indent=2))
        return 2
    errors = check_package(manifest, evidence)
    blocked = live_blockers(manifest) if args.require_live else []
    status = 'INVALID_PACKAGE' if errors else 'LIVE_ACCEPTANCE_BLOCKED' if blocked else 'OFFLINE_PACKAGE_VALID'
    result = {'status': status, 'validation_scope': 'OFFLINE_AUDIT_PACKAGE_ONLY',
              'errors': errors, 'live_blockers': blocked,
              'source_repository_tests_run': False, 'production_changed': False}
    print(json.dumps(result, indent=2) if args.json else f'{status}\n' + '\n'.join(errors + blocked))
    return 1 if errors else 3 if blocked else 0


if __name__ == '__main__':
    raise SystemExit(main())
