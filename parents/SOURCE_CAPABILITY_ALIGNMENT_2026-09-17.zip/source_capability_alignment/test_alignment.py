"""Offline regression tests for evidence accounting; never calls Source."""
import copy
import json
import unittest
from pathlib import Path
from validate_alignment import check_package, live_blockers

ROOT = Path(__file__).resolve().parent


class AlignmentTests(unittest.TestCase):
    def setUp(self):
        self.m = json.loads((ROOT / 'ALIGNMENT_MANIFEST.json').read_text())
        self.e = json.loads((ROOT / 'EVIDENCE_REGISTER.json').read_text())

    def invalid(self):
        self.assertTrue(check_package(self.m, self.e))

    def test_valid_snapshot(self):
        self.assertEqual(check_package(self.m, self.e), [])

    def test_missing_tool(self):
        self.m['native_tool_crosswalk'].pop()
        self.invalid()

    def test_duplicate_native_binding(self):
        self.m['native_tool_crosswalk'][1]['capability_id'] = self.m['native_tool_crosswalk'][0]['capability_id']
        self.invalid()

    def test_duplicate_tool(self):
        self.m['native_tool_crosswalk'][1]['tool_name'] = self.m['native_tool_crosswalk'][0]['tool_name']
        self.invalid()

    def test_projection_count(self):
        self.m['capability_projection_census']['counts']['routes'] += 1
        self.invalid()

    def test_projection_pages(self):
        self.m['capability_projection_census']['page_sizes'][-1] -= 1
        self.invalid()

    def test_unfinished_pagination(self):
        self.m['capability_projection_census']['final_next_cursor'] = 'next'
        self.invalid()

    def test_missing_operation(self):
        self.m['operation_crosswalk'].pop()
        self.invalid()

    def test_context_change_cannot_edit_manifest(self):
        self.m['operation_crosswalk'][-1]['implementation_scope'] = 'CAPABILITY_REGISTRY_UPDATE'
        self.invalid()

    def test_context_change_cannot_be_read(self):
        self.m['operation_crosswalk'][-1]['gate'] = 'READ'
        self.invalid()

    def test_false_runtime_test(self):
        self.m['operation_crosswalk'][0]['runtime_test_in_this_turn'] = True
        self.invalid()

    def test_unresolved_evidence(self):
        self.m['findings'][0]['evidence_ids'] = ['INVENTED']
        self.invalid()

    def test_missing_evidence_limits(self):
        self.e['entries'][0]['limits'] = ''
        self.invalid()

    def test_missing_family(self):
        self.m['product_families'].pop()
        self.invalid()

    def test_family_not_functional_proof(self):
        self.m['product_families'][0]['functional_parity'] = 'VERIFIED'
        self.invalid()

    def test_duplicate_priority(self):
        self.m['prioritized_use_cases'][1]['rank'] = 0
        self.invalid()

    def test_priority_not_measured_roi(self):
        self.m['prioritized_use_cases'][1]['rank_basis'] = 'MEASURED_RETURN'
        self.invalid()

    def test_unknown_use_case(self):
        self.m['native_tool_crosswalk'][0]['primary_use_case'] = 'UNKNOWN'
        self.invalid()

    def test_false_repo_integration(self):
        self.m['delivery_state']['repository_integrated'] = True
        self.invalid()

    def test_false_deployment(self):
        self.m['delivery_state']['production_promoted'] = True
        self.invalid()

    def test_false_live_manifest_change(self):
        self.m['delivery_state']['live_manifest_changed'] = True
        self.invalid()

    def test_identity_not_cli_parity(self):
        self.m['native_tool_crosswalk'][0]['functional_parity'] = 'VERIFIED'
        self.invalid()

    def test_truncated_schema_not_complete(self):
        self.m['canonical_registry']['full_schema_verified'] = True
        self.invalid()

    def test_unread_registry_column_accounting(self):
        self.m['canonical_registry']['unread_column_names'] = 0
        self.invalid()

    def test_skill_census_not_conflated(self):
        self.m['skill_inventory_reported']['postgres_active_count'] += 1
        self.invalid()

    def test_profile_difference(self):
        self.m['web_read_projection']['not_native_in_curated'] = []
        self.invalid()

    def test_bad_generation_hash(self):
        self.m['observation']['schema_fingerprint'] = 'unknown'
        self.invalid()

    def test_no_erasing_residuals(self):
        self.m['residuals'] = []
        self.invalid()

    def test_offline_pass_does_not_close_live_gate(self):
        self.assertFalse(check_package(self.m, self.e))
        self.assertTrue(live_blockers(self.m))

    def test_validator_does_not_mutate_input(self):
        m0, e0 = copy.deepcopy(self.m), copy.deepcopy(self.e)
        check_package(self.m, self.e)
        self.assertEqual(self.m, m0)
        self.assertEqual(self.e, e0)

    def test_malformed_input_fails_closed(self):
        self.assertTrue(check_package({}, {}))

    def test_output_schema_boolean(self):
        self.m['native_tool_crosswalk'][0]['output_schema_declared'] = 'true'
        self.invalid()


if __name__ == '__main__':
    unittest.main()
