# Source capability alignment — 2026-09-17

Status: **PACKAGE UPDATED; SOURCE REPOSITORY/DEPLOYMENT NOT EXECUTED.**

Start with `CAPABILITY_ALIGNMENT.md`. For the selected bounded-graph closure slice, use `GRAPH_CLOSURE_ONESHOT.md`; the complete leverage-ordered program is `IMPLEMENTATION_ONESHOT.md`.

The original 225-declaration/42-native-tool baseline is retained as historical evidence, not claimed as a fresh census. The original ZIP is preserved under `prior/`. This revision does not force a public graph family from VOID to LIVE and does not add Neo4j MCP authority.

## Main files

- `ALIGNMENT_MANIFEST.json`: complete historical crosswalk, updated use-case ranks, current refusal evidence and graph delta.
- `GRAPH_ALIGNMENT_DELTA.json`: seven graph semantic classes; separate exposure, implementation, authority and resource semantics.
- `EVIDENCE_REGISTER.json`: exact evidence handles, official sources and limitations.
- `ACCEPTANCE_MATRIX.json`: original20 plus26 graph-specific Source integration obligations, all NOT_RUN_HERE.
- `verify_graph_evidence.py`: offline exported-evidence consistency checker; no Source execution or live acceptance authority.
- `CONSUMER_EVIDENCE.template.json`: deliberately incomplete template for actual exports; must fail before real evidence is supplied.
- `PACKAGE_DELTA.patch`: changes to the alignment package, NOT a patch against the unavailable Source repository.

## Reproduce local checks

From this extracted package directory:

```sh
python3 -m unittest -v test_alignment test_graph_alignment
python3 validate_alignment.py --package . --json
python3 validate_alignment.py --package . --require-live --json
python3 verify_graph_evidence.py --packet CONSUMER_EVIDENCE.template.json
```

Expected exits: tests0; package validator0; live gate3; incomplete template1. These commands run no network/database/provider operations and do not modify Source.

The synthetic positive fixtures in the tests are not real Source receipts or graph results. Hash validation proves byte integrity only, not external event truth. Actual Source acceptance remains with its existing owners.

## Execution boundary

A real read-only `source-e2e` status invocation returned `PROFILE_ROUTE_DENIED` for `claude_user_read` before the target operation executed. The package records this exact boundary and does not retry through another route. A previous async run was read back as terminal degraded, not left pending.

Do not interpret AGA inactive TTL as active-job timeout, graph drop as observed session termination, or Cypher LIMIT as a universal compute/cost bound. See the report and current official references.
