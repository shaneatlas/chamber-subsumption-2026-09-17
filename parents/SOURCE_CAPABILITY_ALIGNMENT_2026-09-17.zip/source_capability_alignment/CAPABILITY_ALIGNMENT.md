# Source capability alignment — September 17 revision

## Overview

**The alignment package has been edited and its offline checks rerun. Source repository implementation, live graph acceptance and deployment have not occurred in this environment.** A direct attempt to reach the existing `source-e2e` controller for read-only status returned `PROFILE_ROUTE_DENIED`, not an executable handoff. [E12]

This revision incorporates the operator's internal Search-waist correction, preserves the earlier complete returned declaration inventory, and removes three overclaims from the intervening conversation: public `VOID` does not prove global absence; a database result cap does not prove a universal work cap; and AGA inactive TTL does not prove a maximum active-job duration. [U01, H02, N01–N03]

This package is integration input for the existing Source owners. It is not a second registry, provider adapter, Cypher sanitizer, execution controller or grant of public MCP authority.

## What changed and what remains historical

The original ZIP is preserved verbatim under `prior/`. Its 12 recorded file hashes verified, and all 32 baseline offline tests were rerun successfully before editing. The new manifest preserves all 225 baseline declarations, 42 native tool entries, 10 substrate operations and 15 reported product families. These inventories describe the original observation window; they were **not freshly re-enumerated** in this revision. Stable use-case IDs remain unchanged, while leverage ranks and graph acceptance requirements are updated.

The revised package adds a seven-class graph model, 26 graph-specific Source integration obligations, exact current controller refusal and prior-run disposition, a consistency checker for exported consumer evidence, and negative regression tests. The original 20 Source integration obligations remain. All 46 Source integration obligations are still `NOT_RUN_HERE`; their existence does not mean Source passes them.

### Current bounded observations

| Observation | Result and ceiling |
|---|---|
| Mounted files | Original ZIP, manifest, report and one-shot only; no active Source checkout observed |
| `source-e2e` discovery | `DISK_ONLY`, `pg_bound=false`; metadata, not execution [E11] |
| Actual read-only controller probe | `PROFILE_ROUTE_DENIED` under `claude_user_read`; target operation unexecuted [E12] |
| Prior asynchronous run | Reopened existing handle; terminal `degraded`, `ReadTimeout`, acceptance `NOT_OBSERVED` [E13] |
| Generation returned by current calls | `dae69cc80dec0bee`; this is not a new full catalog or served-code inspection [E11–E13] |
| Operator implementation report | Bounded Search/AGA adapter and 29 tests reported; source bytes, logs and live graph effect not independently verified [U01] |

The denied controller operation has no operation receipt. The outer invocation audit ID is `03da0024-382a-5627-aac9-ea295bf6ee1b`. Its outer audit says the tool executed the request handling, while the inner target-operation result says `attempted=false`, `executed=false`. These are different layers, not proof that the controller ran. The response also reports an UNKNOWN/READ gate-class mismatch; do not hide it or infer a bypass from it.

The prior async handle `turn_c2b65ed04a644903a1e78236db646e9b` is now observed terminal, not pending. Its witness reference `witness_receipt:18556` and PASS prose do not establish a delivered answer, independent GDS verification, code edit or deployment. No replacement conferral was launched.

## Correct graph alignment

| Semantic class | Reported owner | Policy to preserve | Current evidence class |
|---|---|---|---|
| Ordinary bounded Cypher | `graph_query` | Internal Search read; database result cap and query timeout | Operator report |
| GDS metadata | `graph_query` | Exact metadata allowlist | Operator report |
| Skill-pair PageRank | `bounded_gds_path_projection` | Dedicated AGA compute with scoped cost gate | Operator report |
| Unbounded GDS stream | `graph_query` | Refused by design | Operator report; actual negative test evidence required |
| GDS write/mutate | `graph_query` | Refused by design | Operator report; actual negative test evidence required |
| Arbitrary projection | `graph_query` | Refused by design | Operator report; actual negative test evidence required |
| Neo4j MCP GDS catalog | Plugin reference interface | Discovery/reference, not authority for this Search route | Operator report |

`REFUSED_BY_DESIGN` is a valid policy disposition. It becomes a verified refusal only after the appropriate mechanical negative test passes; recording the words is not enough.

The public family ledger's `graph_gds: VOID / SKILL_ONLY` can remain correct for its public profile. The actual defect to resolve is the inability—or incorrect client interpretation—to distinguish this profile's exposure from internal capability. Determine the generator's contract before changing its output. Preserve existing `LIVE | PARTIAL | VOID` compatibility and add or use orthogonal implementation/exposure/authorization/effect/verification dimensions. No new public tool or scope widening is required merely because an internal adapter exists.

### Bounds must have precise meanings

The operator reports a database-executed maximum 50-row limit, a 15-second driver query timeout and finite fetching for ordinary Search. That fixes the original post-fetch-slice problem, but a final LIMIT constrains returned rows, not all preceding computation. Neo4j's Top example returns two rows after reading more upstream rows. LIMIT also does not prevent writes in the same query part. Query shape, execution policy, deadline and result-byte caps therefore remain separate obligations. [N01–N02]

The reported 2,000-row Skill-pair extraction bounds inputs to the temporary projection. It does not necessarily mean 2,000 unique nodes: two endpoints per pair imply up to 4,000 distinct endpoints. Verify projected membership and no expansion beyond the admitted input. A sampled-subgraph PageRank result must stay labeled as such, not global skill importance or evidentiary authority. Selection order and reproducibility also require explicit treatment; unspecified LIMIT ordering is not guaranteed. [U01, N01]

AGA `memory=2GB` is a session allocation setting. When PT5M is passed as the provider's `ttl`, it controls expiration after inactivity. An active-job deadline, cancellation propagation and observed resource termination require independent evidence. The actual Source helper may provide additional controls; that remains uninspected, not presumed absent. [N03]

Billable AGA uses a ten-minute minimum billed duration. A five-minute inactive TTL is therefore not a five-minute billing ceiling. Free/trial exemptions require actual account qualification; this work inspected neither the account tier nor tariff or invoice. No provider spend or production AGA session was started here. [N04–N05]

A graph drop and session resource termination are separate evidence predicates. The existing helper may close both in one operation; verify its behavior rather than creating duplicate cleanup or claiming termination from a graph-delete response alone. Reused sessions require their own owner/budget/expiry contract.

## Revised leverage order

The order is engineering judgment based on reuse and the operator's current implementation report, not measured ROI. Keep security, identity and readback requirements on every slice.

| Rank | Stable ID | Delivery target |
|---|---|---|
| 0 | P0 | Bounded identity, effects, authority and complete readback prerequisite |
| 1 | UC01 | Owned task/session continuity |
| 2 | UC02 | General Source evidence retrieval and reranking |
| 3 | UC07 | Existing bounded internal graph intelligence and consumer chain |
| 4 | UC04 | Reasoning/routing/perception/conferral |
| 5 | UC03 | Bounded execution and accepted closure |
| 6 | UC05 | Artifact ingestion, correction and retraction |
| 7 | UC06 | Actionable diagnostics and proof inspection |
| 8 | UC08 | Outcome assessment and governed learning |
| 9 | UC09 | Target-specific fleet/update/repair operations |
| 10 | UC10 | Specialized domain packs and compatibility |

Do not wait for every skill to be reaudited before delivering the selected slice. Do not substitute repeated provider panels, health checks or new plans for implementation. Existing unrelated diagnostic/fleet failures stay parallel residuals unless they block this precise journey.

## Actual implementation handoff

`GRAPH_CLOSURE_ONESHOT.md` is the controlling narrow graph handoff. `IMPLEMENTATION_ONESHOT.md` remains the complete program, updated with the new ordering and correction precedence. Both require the current actual Source checkout, existing owners and exact target-specific release gates. Historical commits are pins to compare against, not instructions to reset or restore.

The first graph consumer checkpoint is:

`owned task/request → authorization and budget → admitted Skill pairs → owned AGA projection/session → bounded PageRank → complete result → cleanup → downstream consumption → assessed outcome`

No step can be inferred from the adjacent step. Every result must carry input/result identity, actual execution-plane provenance, scope limitations, resource and cleanup status, and the exact downstream consumer binding.

`verify_graph_evidence.py` can read an exported packet and its referenced bytes. It checks structure, exact hashes, request/generation joins, subset membership, cardinality, resource-policy fields, public no-widening declarations, cleanup/consumer fields and required test evidence references. It does **not** authenticate Source receipts, prove that reported events occurred, inspect actual Cypher semantics or execute Source. A passing export still requires the existing independent Source adjudication. Synthetic test fixtures are labeled and never yield a live/closed verdict. The provided evidence template intentionally fails until actual data is supplied.

## Validation and remaining boundary

`TEST_REPORT.json`, `UNIT_TESTS.txt` and `VALIDATION_RESULT.json` record the rerun offline checks for this revision. `LIVE_ACCEPTANCE_RESULT.json` intentionally remains blocked. `TEMPLATE_VALIDATION_RESULT.json` records the empty template's expected rejection. Neither the new offline test count nor the operator's separate 29-test report proves Source integration here.

The old complete scope, original observations, open questions and test requirements are preserved in the original ZIP and the current historical crosswalk. The concrete current missing execution surface is the denied `source-e2e` route and absent mounted checkout—not a generic need to "enable all writes." Do not use context-field writes, alternate federation, credential changes or MCP grants as substitutes.

## Sources · Assumptions · Next steps

**Sources:** E01–E10/P01–P04/H01/W01 are retained baseline records. U01 is the operator implementation report. E11–E13 are this turn's bounded observations. H02–H03 are prior-turn observations. N01–N05 are official Neo4j documentation checked September 17, 2026. Exact URLs, IDs and limitations are in `EVIDENCE_REGISTER.json`.

**Assumptions:** The accepted task is the Source shared CLI/API/MCP utility build; the internal Search boundary and target-specific gates remain controlling. Operator reports are not replaced with unsupported live status.

**Next step:** Consume the amended one-shot in the actual repository-capable Source execution environment, implement only the evidenced delta, run the real integration matrix and return complete consumer evidence through the existing acceptance owner. This package itself does not launch that environment.
